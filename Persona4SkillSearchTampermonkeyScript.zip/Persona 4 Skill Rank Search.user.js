// ==UserScript==
// @name         Persona 4 Skill Rank Search
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Persona 4 Skill Rank Search
// @author       You
// @match        https://aqiu384.github.io/megaten-fusion-tool/p4g/skills
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

function createSkillQueryForm() {
    let skillForm = document.createElement("form");
    skillForm.classList.add("skillInput");
    skillForm.innerHTML = `
      <input type="text" name="skillInput" placeholder="bash,garu...">
      <button>query</button>
    `;
    skillForm.addEventListener("submit", (e) => {
      // Stop form from reloading the page
      e.preventDefault();

      // Get the value from the form input
      let skills = skillForm.querySelector("input").value;

      // Input to skill list
      skills = skills.toLowerCase();
      const skillsParsed = skills.split(",");
      let skillList = {};
      skillsParsed.forEach(item => {skillList[item] = 0});

      // Clear the form input
      skillForm.querySelector("input").value = "";

      // Query skill rank
      let skillNameElements = document.querySelectorAll(".app-smt-skill-list-row > td:first-child + td");
      skillNameElements.forEach((item) => {
          if (skillList.hasOwnProperty(item.innerText.toLowerCase())) {
              item.style.backgroundColor = "pink";
              console.log(item);
              item.parentElement.querySelector("td:first-child + td + td + td + td").style.backgroundColor = "pink";
              skillList[item.innerText.toLowerCase()] = item.parentElement.querySelector("td:first-child + td + td + td + td").innerText;
          }
      });

      //Output query result
      let result = "";
      for (const property in skillList) {
          console.log(`${property}: rank ${skillList[property]}`);
          let newline = String.fromCharCode(13, 10);
          result = result.concat(`${property}: rank ${skillList[property]}${newline}`);
      }
      document.querySelector(".skillQueryResult").innerHTML = result;
    });

    return skillForm;
}

window.onload = function () {
    let form = createSkillQueryForm();
    let resultDisplay = document.createElement("textarea");
    resultDisplay.classList.add("skillQueryResult");
    resultDisplay.setAttribute("rows", "5");
    resultDisplay.setAttribute("cols", "30");

    document.querySelector("app-smt-skill-list").prepend(resultDisplay);
    document.querySelector("app-smt-skill-list").prepend(form);
};